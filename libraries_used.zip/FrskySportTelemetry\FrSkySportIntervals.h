#ifndef _FRSKY_SPORT_INTERVALS_H_
#define _FRSKY_SPORT_INTERVALS_H_

// Mindestabstand in ms zwischen zwei gesendeten Werten (hier zentral anpassen).
// Der Sender fragt die Sensoren selbst ab, die Werte erscheinen also höchstens so oft.

// Vario
#define VARIO_ALT_DATA_PERIOD 200
#define VARIO_VSI_DATA_PERIOD 100

// GPS
#define GPS_LAT_LON_DATA_PERIOD   1000
#define GPS_ALT_DATA_PERIOD       500
#define GPS_SPEED_DATA_PERIOD     500
#define GPS_COG_DATA_PERIOD       500
#define GPS_DATE_TIME_DATA_PERIOD 10000
// 1 = Datum/Uhrzeit senden, 0 = weglassen (spart zwei Abfrage-Slots im GPS-Sensor)
#define GPS_SEND_DATE_TIME        1

// RPM-Sensor (Flugmodus, Satelliten, Fix-Typ)
#define RPM_T1_DATA_PERIOD  1000
#define RPM_T2_DATA_PERIOD  1000
#define RPM_ROT_DATA_PERIOD 500

#endif
