#include "NazaCanDecoder.h"
#include <math.h>

NazaCanDecoder::NazaCanDecoder() {
  for(uint8_t i=0; i<NAZA_MESSAGE_COUNT; i++) {
    collectData[i] = 0; msgIdx[i] = 0; header[i] = 0; footer[i] = 0;
  }
  battery = 0; becVoltage = 0; homeLatDeg = 0; homeLonDeg = 0;
  for(uint8_t c = 0; c < 10; c++) rcInValue[c] = 0;
}

uint16_t NazaCanDecoder::decode(uint32_t id, uint8_t *buf, uint8_t len) {
  uint16_t msgId = NAZA_MESSAGE_NONE;
  
  if(id == 0x090) canMsgIdIdx = 0;
  else if(id == 0x108) canMsgIdIdx = 1;
  else if(id == 0x7F8) canMsgIdIdx = 2;
  else return msgId;

  for(uint8_t i = 0; i < len; i++) {
    canMsgByte = buf[i];
    if(collectData[canMsgIdIdx] == 1) {
      if(msgIdx[canMsgIdIdx] >= sizeof(msgBuf[canMsgIdIdx].bytes)) {
        collectData[canMsgIdIdx] = 0;
      }
      else if(msgIdx[canMsgIdIdx] >= 4 &&
              (uint32_t)msgIdx[canMsgIdIdx] >= (uint32_t)msgLen[canMsgIdIdx] + 4) {
        // Keep the footer out of the message buffer until its full marker is seen.
      }
      else {
        msgBuf[canMsgIdIdx].bytes[msgIdx[canMsgIdIdx]] = canMsgByte;
        if(msgIdx[canMsgIdIdx] == 3) {
          msgLen[canMsgIdIdx] = msgBuf[canMsgIdIdx].header.len;
          if((uint32_t)msgLen[canMsgIdIdx] + 4 > sizeof(msgBuf[canMsgIdIdx].bytes)) {
            collectData[canMsgIdIdx] = 0;
          }
        }
        if(collectData[canMsgIdIdx] != 0) msgIdx[canMsgIdIdx] += 1;
      }
    }
     
    if(canMsgByte == 0x55) { if(header[canMsgIdIdx] == 0) header[canMsgIdIdx] = 1; else if(header[canMsgIdIdx] == 2) header[canMsgIdIdx] = 3; else header[canMsgIdIdx] = 0;}
    else if(canMsgByte == 0xAA) { if(header[canMsgIdIdx] == 1) header[canMsgIdIdx] = 2; else if(header[canMsgIdIdx] == 3) { header[canMsgIdIdx] = 0; collectData[canMsgIdIdx] = 1; msgIdx[canMsgIdIdx] = 0; statStart++; } else header[canMsgIdIdx] = 0;}
    else header[canMsgIdIdx] = 0;
    
    // Footer 66 CC 66 CC nur am erwarteten Nachrichtenende akzeptieren; dieselbe Bytefolge im Nutzinhalt ignorieren.
    if(canMsgByte == 0x66) { footer[canMsgIdIdx] = (footer[canMsgIdIdx] == 2) ? 3 : 1; }
    else if(canMsgByte == 0xCC) {
      if(footer[canMsgIdIdx] == 1) footer[canMsgIdIdx] = 2;
      else if(footer[canMsgIdIdx] == 3) {
        footer[canMsgIdIdx] = 0;
        if(collectData[canMsgIdIdx] == 1 && msgIdx[canMsgIdIdx] >= 4 &&
           (uint32_t)msgIdx[canMsgIdIdx] >= (uint32_t)msgLen[canMsgIdIdx] + 4) collectData[canMsgIdIdx] = 2;
      }
      else footer[canMsgIdIdx] = 0;
    }
    else footer[canMsgIdIdx] = 0;
    
    if(collectData[canMsgIdIdx] == 2) {
      if(msgIdx[canMsgIdIdx] == (msgLen[canMsgIdIdx] + 4)) {
        statOk++;
        if(msgBuf[canMsgIdIdx].header.id == NAZA_MESSAGE_MSG1002) {
          float q0 = msgBuf[canMsgIdIdx].msg1002.quaternion[0];
          float q1 = msgBuf[canMsgIdIdx].msg1002.quaternion[1];
          float q2 = msgBuf[canMsgIdIdx].msg1002.quaternion[2];
          float q3 = msgBuf[canMsgIdIdx].msg1002.quaternion[3];
          heading = atan2(2.0 * (q3 * q0 + q1 * q2) , -1.0 + 2.0 * (q0 * q0 + q1 * q1)) / M_PI * 180.0;
          if(heading < 0) heading += 360.0;
          sat = msgBuf[canMsgIdIdx].msg1002.numSat;
          lat = msgBuf[canMsgIdIdx].msg1002.lat / M_PI * 180.0;
          lon = msgBuf[canMsgIdIdx].msg1002.lon / M_PI * 180.0;
          alt = msgBuf[canMsgIdIdx].msg1002.altBaro;
          float nVel = msgBuf[canMsgIdIdx].msg1002.northVelocity;
          float eVel = msgBuf[canMsgIdIdx].msg1002.eastVelocity;
          spd = sqrt(nVel * nVel + eVel * eVel);
          vsi = -msgBuf[canMsgIdIdx].msg1002.downVelocity;
          msgId = NAZA_MESSAGE_MSG1002;
        }
        else if(msgBuf[canMsgIdIdx].header.id == NAZA_MESSAGE_MSG1003) {
          uint32_t dateTime = msgBuf[canMsgIdIdx].msg1003.dateTime;
          second = dateTime & 0b00111111; dateTime >>= 6;
          minute = dateTime & 0b00111111; dateTime >>= 6;
          hour = dateTime & 0b00001111; dateTime >>= 4;
          day = dateTime & 0b00011111; dateTime >>= 5; if(hour > 7) day++;
          month = dateTime & 0b00001111; dateTime >>= 4;
          year = dateTime & 0b01111111;
          uint8_t fixType = msgBuf[canMsgIdIdx].msg1003.fixType;
          switch(fixType) {
            case 2 : fix = FIX_2D; break;
            case 3 : fix = FIX_3D; break;
            default: fix = NO_FIX; break;
          }
          msgId = NAZA_MESSAGE_MSG1003;
        }
        else if(msgBuf[canMsgIdIdx].header.id == NAZA_MESSAGE_MSG1009) {
          battery = (float)msgBuf[canMsgIdIdx].msg1009.batVolt / 1000.0f; // in Volt umrechnen
          becVoltage = (float)msgBuf[canMsgIdIdx].msg1009.becVolt / 1000.0f;
          homeLatDeg = msgBuf[canMsgIdIdx].msg1009.homeLat / M_PI * 180.0;
          homeLonDeg = msgBuf[canMsgIdIdx].msg1009.homeLon / M_PI * 180.0;
          for(uint8_t c = 0; c < 10; c++) rcInValue[c] = msgBuf[canMsgIdIdx].msg1009.rcIn[c];
          rollRad = msgBuf[canMsgIdIdx].msg1009.roll;
          pitchRad = msgBuf[canMsgIdIdx].msg1009.pitch;
          roll = (int16_t)(rollRad * 180.0 / M_PI);
          pitch = (int8_t)(pitchRad * 180.0 / M_PI);
          mode = (NazaCanDecoder::mode_t)msgBuf[canMsgIdIdx].msg1009.flightMode;
          msgId = NAZA_MESSAGE_MSG1009;
        }
      }
      else {
        statBad++; badId = msgBuf[canMsgIdIdx].header.id; badLen = msgLen[canMsgIdIdx]; badIdx = msgIdx[canMsgIdIdx];
        for(uint8_t t = 0; t < sizeof(badTail); t++) {
          uint16_t p = (msgIdx[canMsgIdIdx] >= sizeof(badTail)) ? (uint16_t)(msgIdx[canMsgIdIdx] - sizeof(badTail) + t) : t;
          badTail[t] = (p < sizeof(msgBuf[canMsgIdIdx].bytes)) ? msgBuf[canMsgIdIdx].bytes[p] : 0;
        }
      }
      collectData[canMsgIdIdx] = 0;
    }
  }
  return msgId;
}

double NazaCanDecoder::getLat() { return lat; }
double NazaCanDecoder::getLon() { return lon; }
double NazaCanDecoder::getAlt() { return alt; }
double NazaCanDecoder::getSpeed() { return spd; }
NazaCanDecoder::fixType_t NazaCanDecoder::getFixType() { return fix; }
uint8_t NazaCanDecoder::getNumSat() { return sat; }
double NazaCanDecoder::getHeading() { return heading; }
double NazaCanDecoder::getVsi() { return vsi; }
int8_t NazaCanDecoder::getPitch() { return pitch; }
int16_t NazaCanDecoder::getRoll() { return roll; }
uint8_t NazaCanDecoder::getYear() { return year; }
uint8_t NazaCanDecoder::getMonth() { return month; }
uint8_t NazaCanDecoder::getDay() { return day; }
uint8_t NazaCanDecoder::getHour() { return hour; }
uint8_t NazaCanDecoder::getMinute() { return minute; }
uint8_t NazaCanDecoder::getSecond() { return second; }
float NazaCanDecoder::getVoltage() { return battery; }
float NazaCanDecoder::getBecVoltage() { return becVoltage; }
double NazaCanDecoder::getHomeLat() { return homeLatDeg; }
double NazaCanDecoder::getHomeLon() { return homeLonDeg; }
int16_t NazaCanDecoder::getRcIn(uint8_t index) { return index < 10 ? rcInValue[index] : 0; }
NazaCanDecoder::mode_t NazaCanDecoder::getMode() { return mode; }
