#ifndef __NAZACANDECODER_H__
#define __NAZACANDECODER_H__

#include "Arduino.h"

#define NAZA_MESSAGE_COUNT   3
#define NAZA_MESSAGE_NONE    0x0000
#define NAZA_MESSAGE_MSG1002 0x1002
#define NAZA_MESSAGE_MSG1003 0x1003
#define NAZA_MESSAGE_MSG1009 0x1009

class NazaCanDecoder
{
  public:
    typedef enum { NO_FIX = 0, FIX_2D = 2, FIX_3D = 3, FIX_DGPS = 4 } fixType_t;
    typedef enum { MANUAL = 0, GPS = 1, FAILSAFE = 2, ATTI = 3 } mode_t;

    NazaCanDecoder();
    
    // Nimmt die Daten vom MCP2515 entgegen und decodiert sie
    uint16_t decode(uint32_t id, uint8_t *buf, uint8_t len);

    double getLat();
    double getLon();
    double getAlt();
    double getSpeed();
    fixType_t getFixType();
    uint8_t getNumSat();
    double getHeading();
    double getVsi();
    int8_t getPitch();
    int16_t getRoll();
    uint8_t getYear();
    uint8_t getMonth();
    uint8_t getDay();
    uint8_t getHour();
    uint8_t getMinute();
    uint8_t getSecond();
    float getVoltage();
    float getBecVoltage();
    double getHomeLat();  // Grad (Naza liefert vermutlich Bogenmaß wie bei der Position, ungeprüft)
    double getHomeLon();
    int16_t getRcIn(uint8_t index);  // Naza-Eingang 0..9 (Rohwert aus Nachricht 0x1009)
    mode_t getMode();

    // Diagnose: gestartete / vollständige / längenfehlerhafte Naza-Nachrichten
    uint16_t statStart = 0;
    uint16_t statOk = 0;
    uint16_t statBad = 0;
    uint16_t badId = 0, badLen = 0, badIdx = 0;
    uint8_t badTail[8] = {0};  // die letzten 8 gespeicherten Bytes der zuletzt defekten Nachricht
  private:
    typedef struct __attribute__((packed)) { uint16_t id; uint16_t len; } naza_msg_header_t;

    typedef struct __attribute__((packed)) {
      naza_msg_header_t header;
      double lon; double lat; float altGps; float accX; float accY; float accZ;
      float gyrX; float gyrY; float gyrZ; float altBaro; float quaternion[4];
      float unk1[3]; float northVelocity; float eastVelocity; float downVelocity;
      float unk2[3]; int16_t magCalX; int16_t magCalY; int16_t magCalZ; uint8_t unk3[10];
      uint8_t numSat; uint8_t unk4; uint16_t seqNum;
    } naza_msg1002_t;

    typedef struct __attribute__((packed)) {
      naza_msg_header_t header;
      uint32_t dateTime; uint32_t lon; uint32_t lat; uint32_t altGps; uint32_t hae; uint32_t vae;
      uint8_t unk0[4]; int32_t northVelocity; int32_t eastVelocity; int32_t downVelocity;
      uint16_t pdop; uint16_t vdop; uint16_t ndop; uint16_t edop; uint8_t numSat; uint8_t unk1;
      uint8_t fixType; uint8_t unk2; uint8_t fixStatus; uint8_t unk3[3]; uint16_t seqNum;
    } naza_msg1003_t;

    typedef struct __attribute__((packed)) {
      naza_msg_header_t header; uint8_t unk1[4]; uint16_t motorOut[8]; uint8_t unk2[4];
      int16_t rcIn[10]; uint8_t unk3[11]; uint8_t flightMode; uint8_t unk4[8];
      double homeLat; double homeLon; float homeAltBaro; uint16_t seqNum; uint8_t unk5[2];
      float stabRollIn; float stabPitchIn; float stabThroIn; uint8_t unk6[4];
      float actAileIn; float actElevIn; float actThroIn; uint16_t batVolt; uint16_t becVolt;
      uint8_t unk7[4]; uint8_t controlMode; uint8_t unk8[5]; int16_t gyrScalX; int16_t gyrScalY;
      int16_t gyrScalZ; uint8_t unk9[32]; float downVelocity; float altBaro; float roll; float pitch;
    } naza_msg1009_t;

    typedef union {
      uint8_t bytes[256];
      naza_msg_header_t header;
      naza_msg1002_t msg1002;
      naza_msg1003_t msg1003;
      naza_msg1009_t msg1009;
    } naza_msg_t;

    uint8_t canMsgIdIdx;
    uint8_t canMsgByte;
    naza_msg_t msgBuf[NAZA_MESSAGE_COUNT];
    uint16_t msgLen[NAZA_MESSAGE_COUNT];
    uint16_t msgIdx[NAZA_MESSAGE_COUNT];
    uint8_t header[NAZA_MESSAGE_COUNT];
    uint8_t footer[NAZA_MESSAGE_COUNT];
    uint8_t collectData[NAZA_MESSAGE_COUNT];

    double lon; double lat; double alt; double spd; fixType_t fix; uint8_t sat;
    double heading; double vsi; float pitchRad; float rollRad; int8_t pitch; int16_t roll;
    uint8_t year; uint8_t month; uint8_t day; uint8_t hour; uint8_t minute; uint8_t second;
    float battery; float becVoltage; double homeLatDeg; double homeLonDeg; int16_t rcInValue[10]; mode_t mode;
};

#endif // __NAZACANDECODER_H__
